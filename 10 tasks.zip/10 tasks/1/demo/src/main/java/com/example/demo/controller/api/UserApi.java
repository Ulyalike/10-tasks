package com.example.demo.controller.api;

import com.example.demo.dto.UserDto;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.UUID;

@Tag(name = "User Controller", description = "User management API")
public interface UserApi {

    @Operation(summary = "Get user by ID")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "User found"),
            @ApiResponse(responseCode = "404", description = "User not found")
    })
    ResponseEntity<UserDto> getUser(@Parameter(description = "ID of the user") UUID id);

    @Operation(summary = "Get all users")
    List<UserDto> getAllUsers();

    @Operation(summary = "Create user")
    UserDto createUser(UserDto dto);

    @Operation(summary = "Register user")
    String registerUser(UserDto dto);

    @Operation(summary = "Update user fully")
    UserDto updateUser(UUID id, UserDto dto);

    @Operation(summary = "Confirm user")
    String confirmUser(UUID id, UserDto dto);

    @Operation(summary = "Partially update user")
    UserDto patchUser(UUID id, UserDto dto);

    @Operation(summary = "Update only email")
    String updateEmail(UUID id, UserDto dto);

    @Operation(summary = "Delete user")
    String deleteUser(UUID id);

    @Operation(summary = "Hard delete user")
    String hardDelete(UUID id);
}
