package com.example.demo.service;

import com.example.demo.exception.MyCustomException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class PaymentService {

    /**
     * Гарантия: метод пытается повторить операцию 5 раз с задержкой 10 секунд
     * в случае временной ошибки (например, сбой соединения),
     * чтобы повысить вероятность успешного выполнения.
     */
    @Retryable(
            value = MyCustomException.class,
            maxAttempts = 5,
            backoff = @Backoff(delay = 10000))
    public void processPayment() {
        System.out.println("Попытка выполнить payment");
        if (new Random().nextBoolean()) {
            System.out.println("Ошибка, выбрасываем исключение");
            throw new MyCustomException("Временная ошибка");
        }
        System.out.println("Оплата прошла успешно");
    }

    @Recover
    public void recover(MyCustomException e) {
        System.out.println("Все попытки исчерпаны. Обработка ошибки: " + e.getMessage());
    }
}
