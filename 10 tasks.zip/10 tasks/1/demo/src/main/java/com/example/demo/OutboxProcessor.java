package com.example.demo;

import com.example.demo.model.OutboxEvent;
import com.example.demo.repository.OutboxRepository;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import io.micrometer.core.instrument.Counter;
import java.time.Duration;
import java.util.List;

@Slf4j
@Component
public class OutboxProcessor {

    private final OutboxRepository outboxRepository;
    private final MeterRegistry meterRegistry;
    private final Timer processTimer;

    public OutboxProcessor(OutboxRepository outboxRepository, MeterRegistry meterRegistry) {
        this.outboxRepository = outboxRepository;
        this.meterRegistry = meterRegistry;

        // Регистрация метрики времени выполнения
        this.processTimer = Timer.builder("outbox.processor.duration")
                .description("Timer for Outbox processing execution")
                .publishPercentileHistogram() // важно для heatmap
                .publishPercentiles(0.5, 0.95, 0.99) // для SLI и SLA
                .minimumExpectedValue(Duration.ofMillis(1))
                .maximumExpectedValue(Duration.ofSeconds(10))
                .register(meterRegistry);
    }

    @Scheduled(fixedRate = 5000)
    @Transactional
    public void processOutboxEvents() {
        processTimer.record(() -> {
            log.info("Start processing outbox events");

            List<OutboxEvent> events = outboxRepository.findAll();

            for (OutboxEvent event : events) {
                try {
                    log.info("Processing event: {}", event.getValue());

                    // Симулируем отправку в Kafka или другую систему
                    Thread.sleep(100); // Имитируем нагрузку

                    outboxRepository.deleteById(event.getId());

                } catch (Exception e) {
                    log.error("Error processing event", e);
                }
            }

            log.info("Finished processing {} outbox events", events.size());
        });
    }
}
