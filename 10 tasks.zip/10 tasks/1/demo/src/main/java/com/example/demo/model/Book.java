// Book.java
package com.example.demo.model;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "books")
public class Book {
    @Id
    @Column(columnDefinition = "uuid")
    private UUID id = UUID.randomUUID();

    @Column(nullable = false)
    private String title;

    // Владелец книги (User)
    @ManyToOne
    @JoinColumn(name = "owner_id")
    private User owner;

    // геттеры и сеттеры
}
