package com.example.demo.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

@Service
public class NotificationService {

    @Async("taskExecutor")
    public CompletableFuture<String> sendEmailAsync(String email) {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ignored) {}
        System.out.println("Email sent to " + email);
        return CompletableFuture.completedFuture("Email sent");
    }
}
