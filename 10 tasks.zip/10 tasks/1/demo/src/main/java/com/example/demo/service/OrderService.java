package com.example.demo.service;

import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Гарантия exactly-once достигается с помощью идемпотентности и блокировок.
 * В данном примере метод проверяет, выполнялась ли операция ранее (по ID),
 * и только если не выполнялась - выполняет и сохраняет результат.
 */
@Service
public class OrderService {

    private final Set<String> processedOrders = ConcurrentHashMap.newKeySet();

    public synchronized String processOrder(String orderId) {
        if (processedOrders.contains(orderId)) {
            return "Order " + orderId + " уже обработан";
        }
        // Логика обработки заказа
        processedOrders.add(orderId);
        return "Order " + orderId + " обработан успешно";
    }
}
