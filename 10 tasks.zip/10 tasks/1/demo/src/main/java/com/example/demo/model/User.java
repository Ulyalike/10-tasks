package com.example.demo.model;

import jakarta.persistence.*;
import java.util.Set;
import java.util.UUID;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "users")
public class User {

    @Id
    @Column(columnDefinition = "uuid")
    private UUID id = UUID.randomUUID();

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String email;

    @ManyToMany
    @JoinTable(name = "user_university",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "university_id"))
    private Set<University> universities;

    @OneToMany(mappedBy = "owner")
    private Set<Book> books;

    @OneToMany(mappedBy = "owner")
    private Set<Product> products;

}
