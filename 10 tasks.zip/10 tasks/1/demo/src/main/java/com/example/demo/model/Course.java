// Course.java
package com.example.demo.model;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "courses")
public class Course {
    @Id
    @Column(columnDefinition = "uuid")
    private UUID id = UUID.randomUUID();

    @Column(nullable = false)
    private String title;

    // Курс принадлежит университету
    @ManyToOne
    @JoinColumn(name = "university_id")
    private University university;

    // геттеры и сеттеры
}
