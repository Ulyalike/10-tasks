package com.example.demo.repository;

import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@Repository
public class UserRepository {

    private final RestTemplate restTemplate;
    private final WebClient webClient;

    public UserRepository(RestTemplate restTemplate, WebClient webClient) {
        this.restTemplate = restTemplate;
        this.webClient = webClient;
    }

    public String getRandomDataFromRest() {
        String url = "https://api.publicapis.org/random";
        return restTemplate.getForObject(url, String.class);
    }

    public String getRandomDataFromWebClient() {
        String url = "https://api.publicapis.org/random";
        return webClient.get()
                .uri(url)
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }
}
