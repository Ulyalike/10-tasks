package com.example.demo.controller;

import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/products")
@RateLimiter(name = "productRateLimiter")  // rate limiter для всех методов
public class ProductController {

    @GetMapping("/{id}")
    public String getProduct(@PathVariable Long id) {
        return "Product " + id;
    }

    @PostMapping
    public String addProduct(@RequestBody String product) {
        return "Added " + product;
    }
}
