package com.example.demo.service;

import com.example.demo.model.Product;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
public class ProductService {

    @Cacheable(value = "products", key = "#productId")
    @Transactional(readOnly = true)
    public Product getProductById(Long productId) {
        simulateSlowService();
        return new Product(UUID.randomUUID(), "Product " + productId);
    }

    @CachePut(value = "products", key = "#product.id")
    @Transactional
    public Product updateProduct(Product product) {
        // Эмуляция обновления
        return product;
    }

    @CacheEvict(value = "products", key = "#productId")
    @Transactional
    public void deleteProduct(Long productId) {
        // Эмуляция удаления
    }

    private void simulateSlowService() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException ignored) {}
    }
}
