package com.example.demo.controller;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.web.bind.annotation.*;

import java.util.Random;

@RestController
@RequestMapping("/api/v1/orders")
@CircuitBreaker(name = "orderCircuitBreaker", fallbackMethod = "fallback")
public class OrderController {

    @GetMapping("/{id}")
    public String getOrder(@PathVariable String id) {
        if (new Random().nextBoolean()) {
            throw new RuntimeException("Ошибка сервиса");
        }
        return "Order " + id;
    }

    public String fallback(String id, Throwable ex) {
        return "Fallback response for order " + id;
    }
}
