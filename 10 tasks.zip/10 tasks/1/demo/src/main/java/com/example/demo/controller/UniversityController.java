package com.example.demo.controller;

import com.example.demo.service.UniversityService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/universities")
@RequiredArgsConstructor
public class UniversityController {

    private final UniversityService universityService;

    @GetMapping
    public List<String> getAllUniversities() {
        return universityService.getAllUniversities();
    }
}
