// University.java
package com.example.demo.model;

import jakarta.persistence.*;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "universities")
public class University {
    @Id
    @Column(columnDefinition = "uuid")
    private UUID id = UUID.randomUUID();

    @Column(nullable = false)
    private String name;

    // Связь ManyToMany с User
    @ManyToMany(mappedBy = "universities")
    private Set<User> users;

    // Университет может предлагать много курсов (OneToMany)
    @OneToMany(mappedBy = "university")
    private Set<Course> courses;

    // геттеры и сеттеры
}
