package com.example.demo.service;

import com.example.demo.dto.UserDto;
import com.example.demo.model.User;
import com.example.demo.repository.UserJpaRepository;
import com.example.demo.service.OutboxService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
public class UserService {

    private final UserJpaRepository userRepository;
    private final OutboxService outboxService;

    public UserService(UserJpaRepository userRepository, OutboxService outboxService) {
        this.userRepository = userRepository;
        this.outboxService = outboxService;
    }

    private UserDto toDto(User user) {
        UserDto dto = new UserDto();
        dto.setId(user.getId());
        dto.setUsername(user.getUsername());
        dto.setEmail(user.getEmail());
        return dto;
    }

    private User toEntity(UserDto dto) {
        User user = new User();
        if (dto.getId() != null) {
            user.setId(dto.getId());
        }
        user.setUsername(dto.getUsername());
        user.setEmail(dto.getEmail());
        return user;
    }

    // --- Основные CRUD-методы без userId ---

    @Transactional(readOnly = true)
    public List<UserDto> getAllUsers() {
        log.info("getAllUsers called");
        return userRepository.findAll().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public UserDto getUserById(UUID id) {
        log.info("getUserById called with id={}", id);
        return userRepository.findById(id)
                .map(this::toDto)
                .orElse(null);
    }

    @Transactional
    public UserDto createUser(UserDto dto) {
        log.info("createUser called with dto={}", dto);
        User user = toEntity(dto);
        User saved = userRepository.save(user);

        String auditMessage = String.format("{\"userId\":\"%s\", \"action\":\"CREATE\", \"targetUserId\":\"%s\"}",
                saved.getId(), saved.getId());
        outboxService.saveEvent(auditMessage);

        return toDto(saved);
    }

    @Transactional
    public UserDto updateUser(UUID id, UserDto dto) {
        log.info("updateUser called with id={}, dto={}", id, dto);
        return userRepository.findById(id)
                .map(user -> {
                    user.setUsername(dto.getUsername());
                    user.setEmail(dto.getEmail());
                    User updated = userRepository.save(user);

                    String auditMessage = String.format("{\"userId\":\"%s\", \"action\":\"UPDATE\", \"targetUserId\":\"%s\"}",
                            id, id);
                    outboxService.saveEvent(auditMessage);

                    return toDto(updated);
                })
                .orElse(null);
    }

    @Transactional
    public UserDto partialUpdate(UUID id, UserDto dto) {
        log.info("partialUpdate called with id={}, dto={}", id, dto);
        return userRepository.findById(id)
                .map(user -> {
                    if (dto.getUsername() != null) {
                        user.setUsername(dto.getUsername());
                    }
                    if (dto.getEmail() != null) {
                        user.setEmail(dto.getEmail());
                    }
                    User updated = userRepository.save(user);

                    String auditMessage = String.format("{\"userId\":\"%s\", \"action\":\"PARTIAL_UPDATE\", \"targetUserId\":\"%s\"}",
                            id, id);
                    outboxService.saveEvent(auditMessage);

                    return toDto(updated);
                })
                .orElse(null);
    }

    @Transactional
    public String deleteUser(UUID id) {
        log.info("deleteUser called with id={}", id);
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);

            String auditMessage = String.format("{\"userId\":\"%s\", \"action\":\"DELETE\", \"targetUserId\":\"%s\"}",
                    id, id);
            outboxService.saveEvent(auditMessage);

            return "User deleted";
        }
        return "User not found";
    }

    // --- Методы с userId для аудита действий текущего пользователя ---

    @Transactional(readOnly = true)
    public List<UserDto> getAllUsers(UUID userId) {
        log.info("User {} requested getAllUsers", userId);
        return getAllUsers();
    }

    @Transactional(readOnly = true)
    public UserDto getUserById(UUID id, UUID userId) {
        log.info("User {} requested getUserById {}", userId, id);
        return getUserById(id);
    }

    @Transactional
    public UserDto createUser(UserDto dto, UUID userId) {
        log.info("User {} requested createUser with dto {}", userId, dto);
        UserDto created = createUser(dto);

        String auditMessage = String.format("{\"userId\":\"%s\", \"action\":\"CREATE_BY_ADMIN\", \"targetUserId\":\"%s\"}",
                userId, created.getId());
        outboxService.saveEvent(auditMessage);

        return created;
    }

    @Transactional
    public String registerUser(UserDto dto, UUID userId) {
        log.info("User {} requested registerUser with dto {}", userId, dto);
        createUser(dto);
        return "User registered";
    }

    @Transactional
    public UserDto updateUser(UUID id, UserDto dto, UUID userId) {
        log.info("User {} requested updateUser id={}, dto={}", userId, id, dto);
        return updateUser(id, dto);
    }

    @Transactional
    public String confirmUser(UUID id, UserDto dto, UUID userId) {
        log.info("User {} requested confirmUser id={}, dto={}", userId, id, dto);
        // Здесь может быть логика подтверждения email/учётной записи
        return "User confirmed";
    }

    @Transactional
    public UserDto partialUpdate(UUID id, UserDto dto, UUID userId) {
        log.info("User {} requested partialUpdate id={}, dto={}", userId, id, dto);
        return partialUpdate(id, dto);
    }

    @Transactional
    public String updateEmail(UUID id, UserDto dto, UUID userId) {
        log.info("User {} requested updateEmail id={}, dto={}", userId, id, dto);
        return userRepository.findById(id)
                .map(user -> {
                    user.setEmail(dto.getEmail());
                    userRepository.save(user);

                    String auditMessage = String.format("{\"userId\":\"%s\", \"action\":\"EMAIL_UPDATE\", \"targetUserId\":\"%s\"}",
                            userId, id);
                    outboxService.saveEvent(auditMessage);

                    return "Email updated";
                }).orElse("User not found");
    }

    @Transactional
    public String deleteUser(UUID id, UUID userId) {
        log.info("User {} requested deleteUser id={}", userId, id);
        return deleteUser(id);
    }

    @Transactional
    public String hardDelete(UUID id, UUID userId) {
        log.info("User {} requested hardDelete id={}", userId, id);
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);

            String auditMessage = String.format("{\"userId\":\"%s\", \"action\":\"HARD_DELETE\", \"targetUserId\":\"%s\"}",
                    userId, id);
            outboxService.saveEvent(auditMessage);

            return "User hard deleted";
        }
        return "User not found";
    }
}
