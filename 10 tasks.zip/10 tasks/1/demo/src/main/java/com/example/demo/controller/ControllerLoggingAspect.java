package com.example.demo.controller;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;

@Aspect
@Component
public class ControllerLoggingAspect {

    private int counter = 0;  // поле-счётчик вызовов (до и после)

    public int getCounter() {
        return counter;  // геттер для теста
    }

    @Before("execution(* com.example..*Controller.*(..))")
    public void logControllerMethodName(JoinPoint joinPoint) {
        counter++;  // Увеличиваем счётчик перед вызовом метода
        String methodName = joinPoint.getSignature().getName();
        System.out.println("[Before] Вызов метода контроллера: " + methodName);
    }

    @Around("execution(* com.example..*Controller.*(..))")
    public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
        Instant start = Instant.now();

        Object result = joinPoint.proceed(); // вызов целевого метода

        Instant end = Instant.now();
        long duration = Duration.between(start, end).toMillis();

        counter++;  // Увеличиваем счётчик после вызова метода
        System.out.println("[Around] Метод " + joinPoint.getSignature().getName() +
                " выполнился за " + duration + " мс");

        return result;
    }
}
