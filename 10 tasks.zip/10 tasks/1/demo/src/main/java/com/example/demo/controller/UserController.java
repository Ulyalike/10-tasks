package com.example.demo.controller;

import com.example.demo.controller.api.UserApi;
import com.example.demo.dto.UserDto;
import com.example.demo.service.UserService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
@RateLimiter(name = "userRateLimiter")
@CircuitBreaker(name = "userCircuitBreaker", fallbackMethod = "fallback")
public class UserController implements UserApi {

    private final UserService userService;

    // Реализации интерфейсных методов, чтобы компилировалось, но кидаем исключение
    @Override
    public ResponseEntity<UserDto> getUser(UUID id) {
        throw new UnsupportedOperationException("Use getUser with userId header");
    }

    @Override
    public List<UserDto> getAllUsers() {
        throw new UnsupportedOperationException("Use getAllUsers with userId header");
    }

    @Override
    public UserDto createUser(UserDto dto) {
        throw new UnsupportedOperationException("Use createUser with userId header");
    }

    @Override
    public String registerUser(UserDto dto) {
        throw new UnsupportedOperationException("Use registerUser with userId header");
    }

    @Override
    public UserDto updateUser(UUID id, UserDto dto) {
        throw new UnsupportedOperationException("Use updateUser with userId header");
    }

    @Override
    public String confirmUser(UUID id, UserDto dto) {
        throw new UnsupportedOperationException("Use confirmUser with userId header");
    }

    @Override
    public UserDto patchUser(UUID id, UserDto dto) {
        throw new UnsupportedOperationException("Use patchUser with userId header");
    }

    @Override
    public String updateEmail(UUID id, UserDto dto) {
        throw new UnsupportedOperationException("Use updateEmail with userId header");
    }

    @Override
    public String deleteUser(UUID id) {
        throw new UnsupportedOperationException("Use deleteUser with userId header");
    }

    @Override
    public String hardDelete(UUID id) {
        throw new UnsupportedOperationException("Use hardDelete with userId header");
    }

    // Новые методы с обязательным header X-User-Id

    @GetMapping("/{id}")
    public ResponseEntity<UserDto> getUser(@RequestHeader("X-User-Id") UUID userId,
                                           @PathVariable UUID id) {
        UserDto user = userService.getUserById(id, userId);
        if (user == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(user);
    }

    @GetMapping
    public List<UserDto> getAllUsers(@RequestHeader("X-User-Id") UUID userId) {
        return userService.getAllUsers(userId);
    }

    @PostMapping
    public UserDto createUser(@RequestHeader("X-User-Id") UUID userId,
                              @RequestBody UserDto dto) {
        return userService.createUser(dto, userId);
    }

    @PostMapping("/register")
    public String registerUser(@RequestHeader("X-User-Id") UUID userId,
                               @RequestBody UserDto dto) {
        return userService.registerUser(dto, userId);
    }

    @PutMapping("/{id}")
    public UserDto updateUser(@RequestHeader("X-User-Id") UUID userId,
                              @PathVariable UUID id,
                              @RequestBody UserDto dto) {
        return userService.updateUser(id, dto, userId);
    }

    @PutMapping("/confirm/{id}")
    public String confirmUser(@RequestHeader("X-User-Id") UUID userId,
                              @PathVariable UUID id,
                              @RequestBody UserDto dto) {
        return userService.confirmUser(id, dto, userId);
    }

    @PatchMapping("/{id}")
    public UserDto patchUser(@RequestHeader("X-User-Id") UUID userId,
                             @PathVariable UUID id,
                             @RequestBody UserDto dto) {
        return userService.partialUpdate(id, dto, userId);
    }

    @PatchMapping("/email/{id}")
    public String updateEmail(@RequestHeader("X-User-Id") UUID userId,
                              @PathVariable UUID id,
                              @RequestBody UserDto dto) {
        return userService.updateEmail(id, dto, userId);
    }

    @DeleteMapping("/{id}")
    public String deleteUser(@RequestHeader("X-User-Id") UUID userId,
                             @PathVariable UUID id) {
        return userService.deleteUser(id, userId);
    }

    @DeleteMapping("/hard/{id}")
    public String hardDelete(@RequestHeader("X-User-Id") UUID userId,
                             @PathVariable UUID id) {
        return userService.hardDelete(id, userId);
    }

    public ResponseEntity<String> fallback(Exception ex) {
        return ResponseEntity.status(503).body("Service temporarily unavailable: " + ex.getMessage());
    }
}
