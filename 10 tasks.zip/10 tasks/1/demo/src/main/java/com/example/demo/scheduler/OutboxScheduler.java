package com.example.demo.scheduler;

import com.example.demo.model.OutboxEvent;
import com.example.demo.repository.OutboxRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class OutboxScheduler {

    private final OutboxRepository outboxRepository;
    private final KafkaTemplate<String, String> kafkaTemplate;

    @Scheduled(fixedDelay = 5000)
    public void publishEvents() {
        List<OutboxEvent> events = outboxRepository.findAll();

        for (OutboxEvent event : events) {
            try {
                kafkaTemplate.send("user-audit-topic", event.getValue());
                outboxRepository.deleteById(event.getId());
                log.info("Sent outbox message: {}", event.getValue());
            } catch (Exception e) {
                log.error("Failed to send outbox message: {}", event.getValue(), e);
            }
        }
    }
}
