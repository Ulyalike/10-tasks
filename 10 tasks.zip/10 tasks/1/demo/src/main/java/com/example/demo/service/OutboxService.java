package com.example.demo.service;

import com.example.demo.model.OutboxEvent;
import com.example.demo.repository.OutboxRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class OutboxService {

    private final OutboxRepository outboxRepository;

    public void saveEvent(String jsonValue) {
        OutboxEvent event = new OutboxEvent();
        event.setId(UUID.randomUUID());
        event.setValue(jsonValue);
        outboxRepository.save(event);
    }
}