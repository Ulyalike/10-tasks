package com.example.demo;

import com.example.demo.controller.UserController;
import com.example.demo.dto.UserDto;
import com.example.demo.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.UUID;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UserController.class)
public class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @Test
    void getUserPositive1() throws Exception {
        UUID userId = UUID.fromString("11111111-1111-1111-1111-111111111111");

        UserDto user = new UserDto();
        user.setId(userId);
        user.setUsername("Mocked User");  // <-- используем корректный метод

        when(userService.getUserById(userId)).thenReturn(user);

        mockMvc.perform(get("/users/" + userId.toString()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("Mocked User"));
    }

    @Test
    void getUserNegative() throws Exception {
        UUID userId = UUID.fromString("99999999-9999-9999-9999-999999999999");

        when(userService.getUserById(userId)).thenReturn(null);

        mockMvc.perform(get("/users/" + userId.toString()))
                .andExpect(status().isOk()) // или .isNotFound() — зависит от логики контроллера
                .andExpect(content().string(""));
    }
}


