package com.example.demo;

import com.example.demo.controller.ControllerLoggingAspect;
import com.example.demo.controller.UserController;
import com.example.demo.dto.UserDto;
import com.example.demo.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
public class ControllerLoggingAspectTest {

    @Autowired
    private UserController userController;

    @Autowired
    private ControllerLoggingAspect aspect;

    @MockBean
    private UserService userService;

    @Test
    void testCounterIncrement() {
        int initialCounter = aspect.getCounter();

        UUID userId = UUID.randomUUID();

        UserDto user = new UserDto();
        user.setId(userId);              // setId(UUID)
        // Если есть другие поля — заполняем их здесь
        // например user.setUsername("Test User") или user.setEmail("test@example.com");
        // смотри реальные методы UserDto

        when(userService.getUserById(userId)).thenReturn(user);

        userController.getUser(userId);

        int finalCounter = aspect.getCounter();

        assertEquals(initialCounter + 2, finalCounter);
    }
}
