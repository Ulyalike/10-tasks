package com.example.demo;

import com.example.demo.dto.UserDto;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class UserE2ETest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void getUser1() {
        UserDto user = restTemplate.getForObject("http://localhost:" + port + "/users/1", UserDto.class);
        assertThat(user).isNotNull();
        assertThat(user.getUsername()).isEqualTo("Alice");
    }

    @Test
    void getUser2() {
        UserDto user = restTemplate.getForObject("http://localhost:" + port + "/users/2", UserDto.class);
        assertThat(user).isNotNull();
        assertThat(user.getUsername()).isEqualTo("Bob");
    }

    @Test
    void getUserNotFound() {
        ResponseEntity<UserDto> response = restTemplate.getForEntity("http://localhost:" + port + "/users/999", UserDto.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(response.getBody()).isNull();
    }
}

