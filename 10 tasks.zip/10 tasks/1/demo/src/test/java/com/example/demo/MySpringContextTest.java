package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")  // указание использовать application-test.yaml
public class MySpringContextTest {

    @Test
    void contextLoads() {
        // Пустой тест — просто проверяем, что Spring успешно поднял контекст
    }
}
