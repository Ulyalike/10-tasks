package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;
import org.testcontainers.containers.KafkaContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

@SpringBootTest
@Testcontainers
public class KafkaProducerTest {

    @Container
    public static KafkaContainer kafka = new KafkaContainer("confluentinc/cp-kafka:latest");

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Test
    void testSend() {
        kafkaTemplate.send("user-audit-topic", "test-message");
        // Добавь ассерты если хочешь с Consumer
    }
}
