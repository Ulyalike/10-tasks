package com.example.demo;

import org.junit.jupiter.api.Test;

public class SimpleTest {

    @Test
    void simpleTest() {
        System.out.println(">>> Simple test works!");
    }
}
