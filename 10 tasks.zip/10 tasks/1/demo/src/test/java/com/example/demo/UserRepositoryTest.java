package com.example.demo;

import com.example.demo.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class UserRepositoryTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private WebClient webClient;

    // Объявляем без generic
    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @InjectMocks
    private UserRepository userRepository;

    @Test
    void testGetRandomDataFromRest() {
        String expected = "{\"data\":\"test data from rest\"}";
        when(restTemplate.getForObject(anyString(), eq(String.class))).thenReturn(expected);

        String result = userRepository.getRandomDataFromRest();

        assertEquals(expected, result);
        verify(restTemplate).getForObject(anyString(), eq(String.class));
    }

    @Test
    void testGetRandomDataFromWebClient() {
        String expected = "{\"data\":\"test data from webclient\"}";

        when(webClient.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(anyString())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just(expected));

        String result = userRepository.getRandomDataFromWebClient();

        assertEquals(expected, result);

        verify(webClient).get();
        verify(requestHeadersUriSpec).uri(anyString());
        verify(requestHeadersSpec).retrieve();
        verify(responseSpec).bodyToMono(String.class);
    }
}
