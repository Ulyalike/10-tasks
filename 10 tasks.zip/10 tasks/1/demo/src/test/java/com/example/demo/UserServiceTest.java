package com.example.demo;

import com.example.demo.dto.UserDto;
import com.example.demo.model.User;
import com.example.demo.repository.UserJpaRepository;
import com.example.demo.service.OutboxService;
import com.example.demo.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceTest {

    @Mock
    private UserJpaRepository userRepository;

    @Mock
    private OutboxService outboxService;

    @InjectMocks
    private UserService userService;

    @Captor
    private ArgumentCaptor<User> userCaptor;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateUser_shouldSaveUserAndSendOutboxEvent() {
        // given
        UserDto dto = new UserDto();
        dto.setUsername("testuser");
        dto.setEmail("test@example.com");

        User savedUser = new User();
        UUID id = UUID.randomUUID();
        savedUser.setId(id);
        savedUser.setUsername("testuser");
        savedUser.setEmail("test@example.com");

        when(userRepository.save(any(User.class))).thenReturn(savedUser);

        // when
        UserDto result = userService.createUser(dto);

        // then
        assertNotNull(result);
        assertEquals("testuser", result.getUsername());
        assertEquals("test@example.com", result.getEmail());
        verify(userRepository).save(userCaptor.capture());
        verify(outboxService).saveEvent(contains("\"action\":\"CREATE\""));
    }

    @Test
    void testGetUserById_shouldReturnUserDtoWhenFound() {
        UUID id = UUID.randomUUID();
        User user = new User();
        user.setId(id);
        user.setUsername("john");
        user.setEmail("john@example.com");

        when(userRepository.findById(id)).thenReturn(java.util.Optional.of(user));

        UserDto result = userService.getUserById(id);

        assertNotNull(result);
        assertEquals("john", result.getUsername());
        assertEquals("john@example.com", result.getEmail());
    }

    @Test
    void testGetUserById_shouldReturnNullWhenNotFound() {
        UUID id = UUID.randomUUID();
        when(userRepository.findById(id)).thenReturn(java.util.Optional.empty());

        UserDto result = userService.getUserById(id);

        assertNull(result);
    }
}
