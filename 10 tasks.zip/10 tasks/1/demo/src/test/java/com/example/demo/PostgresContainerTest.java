package com.example.demo;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.testcontainers.DockerClientFactory;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.utility.DockerImageName;

@SpringBootTest
@ActiveProfiles("test")
public class PostgresContainerTest {

    private static final Logger log = LoggerFactory.getLogger(PostgresContainerTest.class);

    static PostgreSQLContainer<?> postgresContainer;

    @BeforeAll
    static void setUp() {
        if (!DockerClientFactory.instance().isDockerAvailable()) {
            log.warn("Docker is not available. Skipping container startup.");
            return;
        }

        postgresContainer = new PostgreSQLContainer<>(DockerImageName.parse("postgres:15.3"))
                .withDatabaseName("testdb")
                .withUsername("testuser")
                .withPassword("testpass")
                .withInitScript("init-db.sql");

        postgresContainer.start();

        log.info("Postgres container started");
        log.info("Host: {}", postgresContainer.getHost());
        log.info("Port: {}", postgresContainer.getFirstMappedPort());
        log.info("JDBC URL: {}", postgresContainer.getJdbcUrl());
    }

    @Test
    public void testContainerRunning() {
        if (postgresContainer == null || !postgresContainer.isRunning()) {
            log.warn("Test skipped: container not running.");
            return;
        }

        log.info("Container is running: {}", postgresContainer.isRunning());
        assert postgresContainer.isRunning();
    }
}

