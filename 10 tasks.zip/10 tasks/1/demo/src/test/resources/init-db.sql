CREATE TABLE person (
                        id SERIAL PRIMARY KEY,
                        first_name VARCHAR(50),
                        last_name VARCHAR(50),
                        email VARCHAR(100),
                        age INT
);

CREATE TABLE orders (
                        id SERIAL PRIMARY KEY,
                        person_id INT REFERENCES person(id),
                        product VARCHAR(100),
                        quantity INT,
                        order_date DATE
);
