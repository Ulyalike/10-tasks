package com.example.audit.kafka;

import com.example.audit.service.UserAuditService;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class UserAuditConsumer {

    private final UserAuditService auditService;

    public UserAuditConsumer(UserAuditService auditService) {
        this.auditService = auditService;
    }

    @KafkaListener(topics = "user-audit-topic", groupId = "audit-group")
    public void listen(String message) {
        auditService.saveAuditFromMessage(message);
    }
}
