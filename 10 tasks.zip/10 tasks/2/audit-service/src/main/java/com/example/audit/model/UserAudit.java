package com.example.audit.model;

import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.time.Instant;
import java.util.UUID;

@Table("user_audit")
public class UserAudit {

    @PrimaryKey
    private UUID auditId;

    private UUID userId;

    private String action;

    private String entity;

    private Instant timestamp;

    // Конструктор с параметрами
    public UserAudit(UUID userId, String action, String entity) {
        this.auditId = UUID.randomUUID();
        this.userId = userId;
        this.action = action;
        this.entity = entity;
        this.timestamp = Instant.now();
    }

    // Пустой конструктор (нужен для Spring Data Cassandra)
    public UserAudit() {
    }

    // Геттеры и сеттеры
    public UUID getAuditId() { return auditId; }
    public void setAuditId(UUID auditId) { this.auditId = auditId; }

    public UUID getUserId() { return userId; }
    public void setUserId(UUID userId) { this.userId = userId; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getEntity() { return entity; }
    public void setEntity(String entity) { this.entity = entity; }

    public Instant getTimestamp() { return timestamp; }
    public void setTimestamp(Instant timestamp) { this.timestamp = timestamp; }
}

