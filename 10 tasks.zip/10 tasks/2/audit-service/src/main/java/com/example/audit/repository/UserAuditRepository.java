package com.example.audit.repository;

import com.example.audit.model.UserAudit;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface UserAuditRepository extends CassandraRepository<UserAudit, UUID> {

    List<UserAudit> findByUserId(UUID userId);
}
