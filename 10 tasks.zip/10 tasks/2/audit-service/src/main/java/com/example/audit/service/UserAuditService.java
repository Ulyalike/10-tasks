package com.example.audit.service;

import com.example.audit.model.UserAudit;
import com.example.audit.repository.UserAuditRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Service
public class UserAuditService {

    private final UserAuditRepository repository;
    private final ObjectMapper mapper = new ObjectMapper();

    public UserAuditService(UserAuditRepository repository) {
        this.repository = repository;
    }

    public UserAudit createAudit(UUID userId, String action, String entity) {
        UserAudit audit = new UserAudit();
        audit.setAuditId(UUID.randomUUID());
        audit.setUserId(userId);
        audit.setAction(action);
        audit.setEntity(entity);
        audit.setTimestamp(Instant.now());
        return repository.save(audit);
    }

    public void saveAuditFromMessage(String message) {
        try {
            JsonNode node = mapper.readTree(message);
            UUID userId = UUID.fromString(node.get("userId").asText());
            String action = node.get("action").asText();
            String targetUserId = node.get("targetUserId").asText();

            UserAudit audit = new UserAudit(userId, action, targetUserId);
            repository.save(audit);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<UserAudit> getAuditByUserId(UUID userId) {
        return repository.findByUserId(userId);
    }
}
