package com.example.audit;

import com.example.audit.model.UserAudit;
import com.example.audit.service.UserAuditService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.CassandraContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Testcontainers
public class UserAuditServiceTest {

    @Container
    public static final CassandraContainer<?> cassandraContainer =
            new CassandraContainer<>("cassandra:4.0.0")
                    .withExposedPorts(9042);

    @Autowired
    private UserAuditService auditService;

    @DynamicPropertySource
    static void cassandraProperties(DynamicPropertyRegistry registry) {
        String contactPoint = cassandraContainer.getHost() + ":" + cassandraContainer.getFirstMappedPort();
        registry.add("spring.cassandra.contact-points", () -> contactPoint);
        registry.add("spring.cassandra.keyspace-name", () -> "audit_keyspace");
        registry.add("spring.cassandra.local-datacenter", () -> "datacenter1");
    }

    @Test
    void testCreateAuditPositive() {
        UUID userId = UUID.randomUUID();
        UserAudit audit = auditService.createAudit(userId, "UPDATE", "User");
        assertNotNull(audit);
        assertEquals(userId, audit.getUserId());
        assertEquals("UPDATE", audit.getAction());
        assertEquals("User", audit.getEntity());
        assertNotNull(audit.getTimestamp());
    }

    @Test
    void testGetAuditByUserNegative() {
        UUID nonExistingUserId = UUID.randomUUID();
        List<UserAudit> audits = auditService.getAuditByUserId(nonExistingUserId);
        assertTrue(audits.isEmpty());
    }
}
