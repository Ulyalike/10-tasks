package com.example.audit;

import com.example.audit.model.UserAudit;
import com.example.audit.repository.UserAuditRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.testcontainers.containers.CassandraContainer;
import org.testcontainers.containers.KafkaContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@Testcontainers
public class AuditIntegrationTest {

    @Container
    public static KafkaContainer kafka = new KafkaContainer(DockerImageName.parse("confluentinc/cp-kafka:latest"));

    @Container
    public static CassandraContainer<?> cassandra = new CassandraContainer<>("cassandra:4.1.4")
            .withExposedPorts(9042);

    @Autowired
    private UserAuditRepository auditRepository;

    @Test
    void testAuditConsumedAndSaved() throws InterruptedException {
        // Можно послать тестовое сообщение через KafkaTemplate (подключать его сюда)
        // Или дождаться работы продьюсера из основного сервиса

        // Ждем, чтобы Consumer успел сохранить
        Thread.sleep(3000);

        List<UserAudit> audits = auditRepository.findAll();
        assertThat(audits).isNotEmpty();
        assertThat(audits.get(0).getAction()).isEqualTo("updateUser");
    }
}
